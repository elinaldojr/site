<?php
@session_start();
include "config.php";

function anti_injection($sql){
	$sql = preg_replace("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/","",$sql);
	$sql = trim($sql);
	$sql = strip_tags($sql);
	//$sql = (get_magic_quotes_gpc()) ? $sql : addslashes($sql);
	return $sql;
}

$login = $mysqli->real_escape_string(anti_injection($_POST['login'])); 
$senha = $mysqli->real_escape_string(anti_injection($_POST['senha']));

$sqllogado = $mysqli->query("SELECT emp_cd_empresa, emp_ds_email, emp_ds_login, emp_ds_senha FROM empresa WHERE (emp_ds_login = '$login' OR emp_ds_email = '$login') AND emp_ds_senha = '$senha' AND emp_ds_status = 'liberado'");
$existecadastro = $sqllogado->num_rows;

if (empty($existecadastro)) {

    print "<script>alert('E-mail ou Senha estão errados.')</script>";
	print "<meta http-equiv='refresh' content='0;url=index.php'>"; // redireciona a index	
	
}else{
$rowlogado = $sqllogado->fetch_assoc();	
	
        $_SESSION['login']  = $login;	
		$_SESSION['senha']  = $senha;
		$_SESSION['emp_cd_empresa']  = $rowlogado['emp_cd_empresa'];

print "<meta http-equiv='refresh' content='0;url=home'>";     

}
