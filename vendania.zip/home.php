<main>

    <section class="text-center container">
      <div class="row pt-3">
        <div class="col-lg-6 col-md-6 mx-auto pt-5 my-lg-5">
          <h1 class="fw-light">Fácil e Rápido</h1>
          <p class="lead text-muted">Encontre 80% do que você mais precisa, em apenas 20% do tempo.
          </p>
          <p>
            <a href="#" class="btn btn-primary my-2">Encontrar empresas</a>
            <a href="cadastrar_empresa.html" class="btn btn-secondary my-2">Quero promover minha empresa</a>
          </p>
        </div>
        <div class="col-lg-6 col-md-6"><img src="assets/img/garoto-propaganda.png" alt="" class="img-fluid"></div>
      </div>

      <div class="d-flex flex-wrap justify-content-center mt-1">
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary ">#restaurante</a>
        </div>
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary">#academia</a>
        </div>
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary">#distribuidora</a>
        </div>
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary">#mercado</a>
        </div>
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary">#hortifruti</a>
        </div>
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary">#hotel</a>
        </div>
        <div class="p-2 btn-light border border-1 rounded mx-1 mb-1">
          <a href="" class="text-decoration-none text-secondary">#eventos</a>
        </div>
      </div>
    </section>


    <div class="bg-white py-4 shadow-lg mt-1">
      <div class="container">
        <div class="row align-items-center no-gutters">
          <!-- Features -->
          <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-4">
            <div class="d-flex align-items-center">
              <div class="icon bg-primary rounded-circle text-center fs-3 text-white me-3"
                style="width: 3rem; height: 3rem;">
                <i class="bi bi-cart-plus-fill"></i>
              </div>
              <div class="ml-3">
                <h4 class="mb-0 font-weight-semi-bold">30.000+ Empresas</h4>
                <p class="mb-0">Enjoy a variety of fresh topics</p>
              </div>
            </div>
          </div>
          <!-- Features -->
          <div class="col-xl-4 col-lg-4 col-md-6 mb-lg-0 mb-4">
            <div class="d-flex align-items-center">
              <div class="icon bg-primary rounded-circle text-center fs-3 text-white me-3"
                style="width: 3rem; height: 3rem;">
                <i class="bi bi-bag-plus"></i>
              </div>
              <div class="ml-3">
                <h4 class="mb-0 font-weight-semi-bold">200+ Categorias</h4>
                <p class="mb-0">Find the right instructor for you</p>
              </div>
            </div>
          </div>
          <!-- Features -->
          <div class="col-xl-4 col-lg-4 col-md-12">
            <div class="d-flex align-items-center">
              <div class="icon bg-primary rounded-circle text-center fs-3 text-white me-3"
                style="width: 3rem; height: 3rem;">
                <i class="bi bi-bicycle"></i>
              </div>
              <div class="ml-3">
                <h4 class="mb-0 font-weight-semi-bold">100.000+ Produtos</h4>
                <p class="mb-0">Learn on your schedule</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



    <div class="py-3 bg-light">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center my-2">
          <h4>Recomendadas</h4>
          <div class="btn-group">
            <button type="button" class="btn btn-sm btn-outline-secondary ">Ver todas</button>
          </div>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-4">
          <div class="col ">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/tok_modas.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">Loja Tok Modas <i class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Roupas femininas</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Itabuna-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>lojatokmodas@gmail.com</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@lojatokmodas</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.5</span>
                  <span class="text-muted">(27)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="empresa.html" class="btn btn-sm btn-outline-secondary ">Visitar</a>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>


          <div class="col ">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/kms.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">Agência Kzullo Mídias Sociais <i
                    class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Marketing</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Itabuna-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>agenciakms@gmail.com</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@agenciakms</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.4</span>
                  <span class="text-muted">(132)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/cstma.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">CSTMA <i class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Segurança do Trabalho</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Coaraci-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>contato@cstma.com.br</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@cstma</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.1</span>
                  <span class="text-muted">(15)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/boteco_gaucho.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">Boteco Gaúcho <i class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Bares e Restaurantes</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Itabuna-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>botecogaucho@gmail.com</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@botecogaucho</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.4</span>
                  <span class="text-muted">(231)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--div Recomendadas-->



        <div class="d-flex justify-content-between align-items-center my-3 pt-5">
          <h4>Mais populares</h4>
          <div class="btn-group">
            <button type="button" class="btn btn-sm btn-outline-secondary ">Ver todas</button>
          </div>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
          <div class="col ">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/tok_modas.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">Loja Tok Modas <i class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Roupas femininas</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Itabuna-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>lojatokmodas@gmail.com</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@lojatokmodas</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.5</span>
                  <span class="text-muted">(27)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>


          <div class="col ">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/kms.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">Agência Kzullo Mídias Sociais <i
                    class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Marketing</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Itabuna-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>agenciakms@gmail.com</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@agenciakms</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.4</span>
                  <span class="text-muted">(132)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/cstma.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">CSTMA <i class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Segurança do Trabalho</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Coaraci-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>contato@cstma.com.br</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@cstma</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.1</span>
                  <span class="text-muted">(15)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card shadow h-100">
              <img class="bd-placeholder-img card-img-top img-fluid" aria-label="Placeholder: Thumbnail"
                preserveAspectRatio="xMidYMid slice" alt="imagem" src="assets/img/boteco_gaucho.png" />

              <div class="card-body">
                <h5 class="card-text mb-0">Boteco Gaúcho <i class="bi bi-patch-check-fill text-primary"></i></h5>
                <p class="card-text fst-italic text-black-50 fs-6">em Bares e Restaurantes</p>
                <p class="text-black-50 m-0 "><i class="bi bi-geo-alt-fill me-2 "></i>Itabuna-BA</p>
                <p class="text-black-50 m-0 "><i class="bi bi-envelope-fill me-2"></i>botecogaucho@gmail.com</p>
                <p class="text-black-50 m-0 "><i class="bi bi-instagram me-2"></i><a class="text-muted"
                    href="">@botecogaucho</a></p>

                <div class="lh-1 py-3">
                  <span>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                  </span>
                  <span class="text-warning">4.4</span>
                  <span class="text-muted">(231)</span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary ">Visitar</button>
                  </div>
                  <small class="text-muted">9 mins</small>
                </div>
              </div>
            </div>
          </div>
        </div>


      </div>
    </div>

  </main>
