<footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="container">
      <p class="float-end"><a href="#">Voltar ao topo</a></p>

      <div class="row">
        <div class="col-12 col-md-4">
          <img class="mb-2" src="assets/img/vendania-logo_fundoclaro.png" alt=""  height="20">
          <small class="d-block text-muted">&copy; 2017-<?php echo date("Y");?> Vendania.</small>
          <small class="d-block mb-3 text-muted">Desenvolvido com <i class="bi bi-heart-fill text-danger"></i> por <i>BrutaDesign</i>.</small>
        </div>
        <div class="col-6 col-md">
          <h5>Funcionalidades</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="#">Cool stuff</a></li>
            <li><a class="link-secondary" href="#">Random feature</a></li>
            <li><a class="link-secondary" href="#">Team feature</a></li>
            <li><a class="link-secondary" href="#">Stuff for developers</a></li>
            <li><a class="link-secondary" href="#">Another one</a></li>
            <li><a class="link-secondary" href="#">Last time</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="#">Resource</a></li>
            <li><a class="link-secondary" href="#">Resource name</a></li>
            <li><a class="link-secondary" href="#">Another resource</a></li>
            <li><a class="link-secondary" href="#">Final resource</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Sobre</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="#">Team</a></li>
            <li><a class="link-secondary" href="#">Locations</a></li>
            <li><a class="link-secondary" href="#">Privacy</a></li>
            <li><a class="link-secondary" href="#">Terms</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>


  <script src="assets/js/bootstrap.bundle.min.js"></script>


</body>

</html>