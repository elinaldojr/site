---
title: Dash square
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
