---
title: Dash circle
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
