---
title: Dash square dotted
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
