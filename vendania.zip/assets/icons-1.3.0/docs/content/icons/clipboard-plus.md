---
title: Clipboard plus
categories:
  - Real world
tags:
  - copy
  - paste
---
