---
title: Clipboard check
categories:
  - Real world
tags:
  - copy
  - paste
---
