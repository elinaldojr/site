---
title: Dash
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
