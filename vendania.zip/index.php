<?php require_once 'start.php'; ?>
<?php require_once 'header.php'; ?>
<?php require_once 'navbar.php'; ?>

<?php
$rota = (isset($_GET['url'])) ? $_GET['url'] : 'home';
$rota = explode('/', $rota);
$permissao = array('home', 'login', 'cadastro', 'empresa', 'sair');

if (count($rota) > 0) {
    $pagina = (file_exists("{$rota[0]}.php")) && in_array($rota[0], $permissao) ? $rota[0] : 'erro';
    

    include "{$pagina}.php";
}
?>   
    


<?php require_once 'footer.php'; ?>